let s=0;
while (s <= 10) {
    document.write("<br/>",s);
    s++;
  }

console.log("by aayush");