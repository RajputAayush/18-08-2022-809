const inshan = {FirstName:"aayush", LastName:"rajput", age:20};
for (let A in inshan) {
    document.write("<br/>",A);
  }
document.write("<hr/>");
for (let A in inshan) {
  document.write("<br/>",inshan[A]);
}

console.log("by aayush")