let i=0;
do{
  document.write("The number is ",i,"<br/>");
  i++;
}
while (i <= 10);

console.log("sujal");