
const anime = ["Naruto", "My Hero academia ", "Vin land saga"];
for (a of anime) {
  document.write("<br/>",a);
}

console.log("by aayush");