"<hr>";
document.write("Here we have taken two numbers s1 and s2 as 1969 and 2022 ");

let s1=1969,s2=2022;

var sum=s1+s2,mul=s1*s2,sub=s1-s2,div=s1/s2,mod=s1%s2;
var Exponentiation=5**2; // Same as pow.
document.write("<br/>Sum:",sum+"<br/>Mul:",mul+"<br/>Sub:"
,sub+"<br/>Div:",div+"<br/>Modulo:",mod+"<br/>Post Inc for s1:",s1++ ,"<br/>Post Inc for s2:",s2++,
"<br/>Post Dec for s1:",s1--,"<br/>Post Dec for s2:",s2--,"<br/>Pre Inc for s1:",++s1,"<br/>Pre Inc for s2:",++s2,
"<br/>Pre Dec for s1:",--s1,"<br/>Pre Dec for s2:",--s2,"<br/>Exp:",Exponentiation,"<br/><hr/>");

document.write("Here we have taken  number ");

var raju = 200;
raju += 5;

document.write("<br/> here is that number :","\xa0 \xa0",raju,"<hr/>");

document.write("Here is the author of this code <br/>\xa0\xa0\xa0\xa0");
let f0 = "\xa0 \xa0 \xa0 \xa0 \xa0 \xa0 \xa0 \xa0 \xa0 \xa0 \xa0 \xa0 \xa0 \xa0 \xa0 \xa0 \xa0 \xa0 \xa0 \xa0 \xa0 \xa0 \xa0 \xa0\xa0 \xa0 By";
let f1 = "\xa0 \xa0aayush";
let f2 = "\xa0 \xa0rajput";
let f3 = f0 + f1 + " " + f2;
document.write(f3,"<hr/>");




console.log("by aayush");