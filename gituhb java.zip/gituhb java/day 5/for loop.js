for (let i = 0; i <= 10; i++){
    document.write("this number is " , i , "<br/>");
}