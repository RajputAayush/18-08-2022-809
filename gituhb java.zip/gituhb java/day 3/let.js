
let Aayush=prompt("Write your full name");
document.write(Aayush);

let y = 2003;
document.write(y, "\n");

let x= 2069;
document.write("to",x );


